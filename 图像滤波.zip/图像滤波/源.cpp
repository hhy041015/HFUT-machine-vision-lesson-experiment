#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <string>
#include <limits>

// ͼ�����ݽṹ
struct Image {
    int width, height, channels;
    std::vector<unsigned char> data;

    Image(int w, int h, int c) : width(w), height(h), channels(c) {
        data.resize(w * h * c, 0);
    }

    unsigned char& at(int x, int y, int c) {
        // �߽���
        if (x < 0) x = 0;
        if (x >= width) x = width - 1;
        if (y < 0) y = 0;
        if (y >= height) y = height - 1;
        if (c < 0) c = 0;
        if (c >= channels) c = channels - 1;

        return data[(y * width + x) * channels + c];
    }

    const unsigned char& at(int x, int y, int c) const {
        // �߽���
        if (x < 0) x = 0;
        if (x >= width) x = width - 1;
        if (y < 0) y = 0;
        if (y >= height) y = height - 1;
        if (c < 0) c = 0;
        if (c >= channels) c = channels - 1;

        return data[(y * width + x) * channels + c];
    }
};

// BMP�ļ�ͷ�ṹ���򻯰棩
#pragma pack(push, 1)
struct BMPHeader {
    uint16_t signature;
    uint32_t fileSize;
    uint32_t reserved;
    uint32_t dataOffset;
    uint32_t headerSize;
    int32_t width;
    int32_t height;
    uint16_t planes;
    uint16_t bitsPerPixel;
    uint32_t compression;
    uint32_t imageSize;
    int32_t xPixelsPerM;
    int32_t yPixelsPerM;
    uint32_t colorsUsed;
    uint32_t colorsImportant;
};
#pragma pack(pop)

// ��ȫ��ȡ����ֵ�ĺ���
inline unsigned char getPixelSafely(const Image& img, int x, int y, int c) {
    if (x < 0 || x >= img.width || y < 0 || y >= img.height || c < 0 || c >= img.channels) {
        return 0;
    }
    return img.data[(y * img.width + x) * img.channels + c];
}

// ͼ����غͱ��溯��
Image loadBMP(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        throw std::runtime_error("�޷����ļ�: " + filename);
    }

    BMPHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(header));

    if (header.signature != 0x4D42) { // "BM"
        throw std::runtime_error("������Ч��BMP�ļ�");
    }

    if (header.bitsPerPixel != 24) {
        throw std::runtime_error("ֻ֧��24λBMP�ļ�");
    }

    // �ƶ�����������λ��
    file.seekg(header.dataOffset, std::ios::beg);

    int height = std::abs(header.height);
    Image img(header.width, height, 3);

    // BMP�洢˳����BGR���ҿ��ܵ���
    int stride = ((header.width * 3 + 3) & ~3); // ÿ���ֽ�����4�ֽڶ��룩
    std::vector<unsigned char> row(stride);

    for (int y = height - 1; y >= 0; --y) {
        file.read(reinterpret_cast<char*>(row.data()), stride);
        for (int x = 0; x < img.width; ++x) {
            img.at(x, y, 2) = row[x * 3 + 0]; // B -> R
            img.at(x, y, 1) = row[x * 3 + 1]; // G -> G
            img.at(x, y, 0) = row[x * 3 + 2]; // R -> B
        }
    }

    return img;
}

void saveBMP(const std::string& filename, const Image& img) {
    std::ofstream file(filename, std::ios::binary);

    BMPHeader header;
    header.signature = 0x4D42;
    header.reserved = 0;
    header.headerSize = 40;
    header.planes = 1;
    header.bitsPerPixel = 24;
    header.compression = 0;
    header.xPixelsPerM = 2835;
    header.yPixelsPerM = 2835;
    header.colorsUsed = 0;
    header.colorsImportant = 0;

    int stride = ((img.width * 3 + 3) & ~3);
    header.imageSize = stride * img.height;
    header.fileSize = sizeof(BMPHeader) + header.imageSize;
    header.dataOffset = sizeof(BMPHeader);
    header.width = img.width;
    header.height = img.height;

    file.write(reinterpret_cast<const char*>(&header), sizeof(header));

    std::vector<unsigned char> row(stride, 0);

    for (int y = img.height - 1; y >= 0; --y) {
        for (int x = 0; x < img.width; ++x) {
            row[x * 3 + 0] = img.at(x, y, 2); // B
            row[x * 3 + 1] = img.at(x, y, 1); // G
            row[x * 3 + 2] = img.at(x, y, 0); // R
        }
        file.write(reinterpret_cast<const char*>(row.data()), stride);
    }
}

// �Ľ��ľ�����������
Image convolve(const Image& src, const std::vector<std::vector<float>>& kernel) {
    Image dst(src.width, src.height, src.channels);
    int kSize = kernel.size();
    int kRadius = kSize / 2;

    for (int c = 0; c < src.channels; ++c) {
        for (int y = 0; y < src.height; ++y) {
            for (int x = 0; x < src.width; ++x) {
                float sum = 0.0f;
                float weightSum = 0.0f;

                for (int ky = -kRadius; ky <= kRadius; ++ky) {
                    for (int kx = -kRadius; kx <= kRadius; ++kx) {
                        int px = x + kx;
                        int py = y + ky;

                        if (px >= 0 && px < src.width && py >= 0 && py < src.height) {
                            float pixel = getPixelSafely(src, px, py, c);
                            float weight = kernel[ky + kRadius][kx + kRadius];
                            sum += pixel * weight;
                            weightSum += weight;
                        }
                    }
                }

                // �������
                if (std::abs(weightSum) < 1e-6f) {
                    weightSum = 1.0f;
                }

                // ��һ��
                float result = sum / weightSum;

                // ���Ƶ�0-255��Χ
                dst.at(x, y, c) = static_cast<unsigned char>(
                    std::max(0.0f, std::min(255.0f, result)));
            }
        }
    }

    return dst;
}

// Sobel�����˲�
Image sobelFilter(const Image& src) {
    // ת��Ϊ�Ҷ�ͼ
    Image gray(src.width, src.height, 1);
    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            float r = getPixelSafely(src, x, y, 0);
            float g = getPixelSafely(src, x, y, 1);
            float b = getPixelSafely(src, x, y, 2);
            gray.at(x, y, 0) = static_cast<unsigned char>(0.299f * r + 0.587f * g + 0.114f * b);
        }
    }

    // Sobel���Ӻ�
    std::vector<std::vector<float>> sobelX = {
        {-1, 0, 1},
        {-2, 0, 2},
        {-1, 0, 1}
    };

    std::vector<std::vector<float>> sobelY = {
        {-1, -2, -1},
        {0, 0, 0},
        {1, 2, 1}
    };

    Image gradX = convolve(gray, sobelX);
    Image gradY = convolve(gray, sobelY);

    // �����ݶȷ�ֵ
    Image result(src.width, src.height, 1);
    for (int y = 0; y < src.height; ++y) {
        for (int x = 0; x < src.width; ++x) {
            float gx = gradX.at(x, y, 0) - 128.0f; // �ָ��з���
            float gy = gradY.at(x, y, 0) - 128.0f;
            float magnitude = std::sqrt(gx * gx + gy * gy);
            result.at(x, y, 0) = static_cast<unsigned char>(
                std::max(0.0f, std::min(255.0f, magnitude)));
        }
    }

    return result;
}

// �����������˲�
Image customFilter(const Image& src) {
    std::vector<std::vector<float>> kernel = {
        {1, 0, -1},
        {2, 0, -2},
        {1, 0, -1}
    };

    return convolve(src, kernel);
}

// ������ɫֱ��ͼ
std::vector<std::vector<int>> computeColorHistogram(const Image& img, int bins = 256) {
    std::vector<std::vector<int>> histograms(3, std::vector<int>(bins, 0));

    for (int y = 0; y < img.height; ++y) {
        for (int x = 0; x < img.width; ++x) {
            for (int c = 0; c < 3; ++c) {
                unsigned char pixel = getPixelSafely(img, x, y, c);
                int bin = static_cast<int>(pixel) * bins / 256;
                if (bin >= bins) bin = bins - 1;
                histograms[c][bin]++;
            }
        }
    }

    return histograms;
}

// �����������������ڻҶȹ�������
std::vector<float> computeTextureFeatures(const Image& grayImg) {
    int levels = 8; // �Ҷȼ���
    std::vector<std::vector<int>> glcm(levels, std::vector<int>(levels, 0));

    // �����Ҷȹ������󣨾���=1���Ƕ�=0�㣩
    for (int y = 0; y < grayImg.height; ++y) {
        for (int x = 0; x < grayImg.width - 1; ++x) {  // ע��߽�
            int i = (getPixelSafely(grayImg, x, y, 0) * levels) / 256;
            int j = (getPixelSafely(grayImg, x + 1, y, 0) * levels) / 256;
            if (i >= levels) i = levels - 1;
            if (j >= levels) j = levels - 1;
            glcm[i][j]++;
        }
    }

    // ������������
    float energy = 0.0f, contrast = 0.0f, homogeneity = 0.0f, entropy = 0.0f;
    int total = 0;

    // ��������ܺ����ڹ�һ��
    for (int i = 0; i < levels; ++i) {
        for (int j = 0; j < levels; ++j) {
            total += glcm[i][j];
        }
    }

    if (total == 0) {
        return { 0.0f, 0.0f, 0.0f, 0.0f };
    }

    for (int i = 0; i < levels; ++i) {
        for (int j = 0; j < levels; ++j) {
            float p = static_cast<float>(glcm[i][j]) / total;
            if (p > 0) {
                energy += p * p;
                contrast += (i - j) * (i - j) * p;
                homogeneity += p / (1 + std::abs(i - j));
                entropy -= p * std::log(p);
            }
        }
    }

    return { energy, contrast, homogeneity, entropy };
}

// ��������������npy��ʽ���򻯰棩
void saveTextureFeaturesToNPY(const std::string& filename, const std::vector<float>& features) {
    std::ofstream file(filename, std::ios::binary);

    // �򻯵�NPYͷ
    const char npy_magic[] = "\x93NUMPY";
    file.write(npy_magic, 6);

    uint8_t major = 1;
    uint8_t minor = 0;
    file.write(reinterpret_cast<const char*>(&major), 1);
    file.write(reinterpret_cast<const char*>(&minor), 1);

    // ͷ������
    uint16_t header_len = 10 + 128;  // �򻯵�ͷ��
    file.write(reinterpret_cast<const char*>(&header_len), 2);

    // ͷ������
    std::string header = "{'descr': '<f4', 'fortran_order': False, 'shape': (4,), }";
    header.resize(header_len, ' ');
    header.back() = '\n';
    file.write(header.data(), header_len);

    // д����������
    for (float f : features) {
        file.write(reinterpret_cast<const char*>(&f), sizeof(float));
    }
}

// ���ӻ�ֱ��ͼ������ASCII������
void visualizeHistogram(const std::vector<std::vector<int>>& histograms) {
    const int display_width = 50; // ASCIIֱ��ͼ����
    const int display_height = 20; // ASCIIֱ��ͼ�߶�

    std::vector<std::vector<int>> normalized(3);
    const char* colors[] = { "Red", "Green", "Blue" };

    for (int c = 0; c < 3; ++c) {
        // ��һ����0-display_height��Χ
        int max_val = *std::max_element(histograms[c].begin(), histograms[c].end());
        normalized[c].resize(histograms[c].size());

        if (max_val > 0) {
            for (size_t i = 0; i < histograms[c].size(); ++i) {
                normalized[c][i] = (histograms[c][i] * display_height) / max_val;
            }
        }

        // ��ӡֱ��ͼ
        std::cout << "\n" << colors[c] << " Channel Histogram:\n";
        std::cout << "Maximum value: " << max_val << "\n";

        for (int h = display_height; h >= 0; --h) {
            for (size_t i = 0; i < histograms[c].size(); i += histograms[c].size() / display_width) {
                std::cout << (normalized[c][i] >= h ? "#" : " ");
            }
            std::cout << "\n";
        }
    }
}

int main() {
    try {
        // ����ͼ���뽫·���滻Ϊ�������ͼ��
        std::string inputImage = "D:\\Users\\Lenovo\\Desktop\\picture.bmp"; // �滻Ϊ����ͼ��·��

        std::cout << "���ڼ���ͼ��: " << inputImage << std::endl;
        Image original = loadBMP(inputImage);

        std::cout << "ͼ����سɹ�: " << original.width << " x " << original.height << std::endl;
        std::cout << "ͼ��ͨ����: " << original.channels << std::endl;

        if (original.width == 0 || original.height == 0) {
            std::cerr << "����: ͼ��ߴ�Ϊ0" << std::endl;
            return 1;
        }

        // 1. Sobel�����˲�
        std::cout << "\n����Ӧ��Sobel�����˲�..." << std::endl;
        Image sobelResult = sobelFilter(original);
        saveBMP("sobel_filtered.bmp", sobelResult);
        std::cout << "Sobel�˲���ɣ��������Ϊ: sobel_filtered.bmp" << std::endl;

        // 2. �����������˲�
        std::cout << "\n����Ӧ���Զ���������˲�..." << std::endl;
        Image customResult = customFilter(original);
        saveBMP("custom_filtered.bmp", customResult);
        std::cout << "�Զ���������˲���ɣ��������Ϊ: custom_filtered.bmp" << std::endl;

        // 3. ���㲢���ӻ���ɫֱ��ͼ
        std::cout << "\n���ڼ�����ɫֱ��ͼ..." << std::endl;
        auto histograms = computeColorHistogram(original);
        std::cout << "\n=== ��ɫֱ��ͼ���ӻ� ===" << std::endl;
        visualizeHistogram(histograms);

        // 4. ������������
        std::cout << "\n���ڼ�����������..." << std::endl;
        Image gray(original.width, original.height, 1);
        for (int y = 0; y < original.height; ++y) {
            for (int x = 0; x < original.width; ++x) {
                float r = getPixelSafely(original, x, y, 0);
                float g = getPixelSafely(original, x, y, 1);
                float b = getPixelSafely(original, x, y, 2);
                gray.at(x, y, 0) = static_cast<unsigned char>(0.299f * r + 0.587f * g + 0.114f * b);
            }
        }

        auto textureFeatures = computeTextureFeatures(gray);
        saveTextureFeaturesToNPY("texture_features.npy", textureFeatures);

        std::cout << "\n=== �������� ===" << std::endl;
        std::cout << "���� (Energy): " << textureFeatures[0] << std::endl;
        std::cout << "�Աȶ� (Contrast): " << textureFeatures[1] << std::endl;
        std::cout << "ͬ���� (Homogeneity): " << textureFeatures[2] << std::endl;
        std::cout << "�� (Entropy): " << textureFeatures[3] << std::endl;
        std::cout << "������������Ϊ: texture_features.npy" << std::endl;

        std::cout << "\n���д�����ɣ�" << std::endl;

    }
    catch (const std::exception& e) {
        std::cerr << "����: " << e.what() << std::endl;
        std::cerr << "��ȷ����" << std::endl;
        std::cerr << "1. �ļ�·����ȷ" << std::endl;
        std::cerr << "2. �ļ���24λBMP��ʽ" << std::endl;
        std::cerr << "3. ���㹻�Ĵ��̿ռ�" << std::endl;
        return 1;
    }
    catch (...) {
        std::cerr << "δ֪��������" << std::endl;
        return 1;
    }

    return 0;
}
